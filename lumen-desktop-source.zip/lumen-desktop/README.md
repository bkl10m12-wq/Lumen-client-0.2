# Lumen Desktop 0.1.0

A very small Android app (plain Java, no libraries) that turns the phone into a landscape "mini PC" shell
for Lumen Launcher. Target: low-end phones (4 GB RAM class). It is a separate app for now; the screens can be
moved into Lumen Launcher once its source is available.

## What it does

- **Desktop** (landscape only): wallpaper, icons, taskbar with Start button, free RAM, battery and clock.
- **Start menu**: every installed app, searchable. Long-press an app to pin it to the desktop; long-press a
  desktop icon to remove it. On the first run, apps with "Lumen" in their name are pinned automatically.
- **File manager**: browse, copy, cut, paste, rename, delete, new folder, hidden files, sort by name/size/date.
- **Mods switch**: select `.jar` files and tap On/Off (renames `x.jar` <-> `x.jar.disabled`), or tap a jar.
- **Download from link**: paste an `https://` direct link, the file is saved into the current folder.
- **.exe / .msi / .bat**: tapping one offers to hand the file to another installed app (for example a Windows
  compatibility app) or to copy its path.

## What it does NOT do

- It does **not** run `.exe` files. There is no Windows compatibility layer in it.
- It cannot open other apps' `Android/data` or `Android/obb` folders. Android blocks that for every file
  manager, even with "All files access". A launcher that keeps its game folder there can only be managed from
  inside that launcher, or if its game folder is moved to shared storage.
- No download browser / Modrinth search yet.

## Status

`FileOps` (copy, move, delete, safe names, redirect-following downloads) is compiled and covered by 30 checks
on a plain JDK. The Android screens (`DesktopActivity`, `FilesActivity`, `FileShare`, `Util`) were **not
compiled or run** where this was written (no Android SDK, and the Google/Maven hosts were unreachable), so the
first CI build may report a compile error.

## Build

GitHub Actions (see `.github/workflows/build.yml` in the repo): `gradle assembleDebug` with Gradle 8.12,
Java 21, Android Gradle Plugin 8.7.3, compileSdk 34, minSdk 26. The APK appears in
`app/build/outputs/apk/debug/`.
