package dev.lumen.desktop;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small file manager: browse, copy, move, rename, delete, new folder, download from a link,
 * and a mods switch (.jar <-> .jar.disabled). Works on shared storage; Android does not let any
 * file manager open other apps' Android/data folders.
 */
public class FilesActivity extends Activity {
	static final String EXTRA_PATH = "path";

	private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
	private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
	private static final String[] SORT_NAMES = {"Name", "Size", "Date"};

	// Clipboard survives between screens of this app.
	private static final List<File> clip = new ArrayList<>();
	private static boolean clipCut;

	private SharedPreferences prefs;
	private File root;
	private File startDir;
	private File cwd;
	private final List<File> items = new ArrayList<>();
	private final LinkedHashSet<File> sel = new LinkedHashSet<>();
	private boolean showHidden = false;
	private int sortMode = 0;
	private final ExecutorService exec = Executors.newSingleThreadExecutor();
	private AlertDialog work;

	private LinearLayout barHolder;
	private TextView pathView;
	private TextView status;
	private TextView pasteBtn;
	private LinearLayout permBox;
	private ListView list;
	private ItemAdapter adapter;
	private boolean listFailed;

	private interface Job {
		String run() throws Exception;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		prefs = getSharedPreferences("lumen", MODE_PRIVATE);
		root = Environment.getExternalStorageDirectory();
		String p = getIntent().getStringExtra(EXTRA_PATH);
		File start = p == null ? null : new File(p);
		cwd = (start != null && start.isDirectory()) ? start : root;
		startDir = cwd;

		LinearLayout page = new LinearLayout(this);
		page.setOrientation(LinearLayout.VERTICAL);
		page.setBackgroundColor(0xFF120C20);

		barHolder = new LinearLayout(this);
		barHolder.setOrientation(LinearLayout.HORIZONTAL);
		barHolder.setGravity(Gravity.CENTER_VERTICAL);
		barHolder.setBackgroundColor(0xFF1C1430);
		barHolder.setPadding(dp(6), 0, dp(6), 0);
		page.addView(barHolder, new LinearLayout.LayoutParams(MATCH, dp(52)));

		permBox = new LinearLayout(this);
		permBox.setOrientation(LinearLayout.VERTICAL);
		permBox.setPadding(dp(16), dp(12), dp(16), dp(12));
		permBox.setBackgroundColor(0xFF3A2A12);
		TextView pm = text("This app needs \"All files access\" to show your files.", 14, Color.WHITE);
		permBox.addView(pm, new LinearLayout.LayoutParams(MATCH, WRAP));
		TextView allow = button("Allow access", v -> askAccess());
		permBox.addView(allow, new LinearLayout.LayoutParams(WRAP, WRAP));
		permBox.setVisibility(View.GONE);
		page.addView(permBox, new LinearLayout.LayoutParams(MATCH, WRAP));

		list = new ListView(this);
		list.setDividerHeight(0);
		adapter = new ItemAdapter();
		list.setAdapter(adapter);
		list.setOnItemClickListener((parent, view, pos, id) -> onRowClick(items.get(pos)));
		list.setOnItemLongClickListener((parent, view, pos, id) -> {
			toggleSelect(items.get(pos));
			return true;
		});
		page.addView(list, new LinearLayout.LayoutParams(MATCH, 0, 1f));

		LinearLayout bottom = new LinearLayout(this);
		bottom.setOrientation(LinearLayout.HORIZONTAL);
		bottom.setGravity(Gravity.CENTER_VERTICAL);
		bottom.setBackgroundColor(0xFF1C1430);
		bottom.setPadding(dp(12), dp(4), dp(8), dp(4));
		status = text("", 12, 0xFFCFC6E8);
		status.setSingleLine(true);
		status.setEllipsize(TextUtils.TruncateAt.END);
		bottom.addView(status, new LinearLayout.LayoutParams(0, WRAP, 1f));
		pasteBtn = button("Paste here", v -> paste());
		pasteBtn.setVisibility(View.GONE);
		bottom.addView(pasteBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
		page.addView(bottom, new LinearLayout.LayoutParams(MATCH, WRAP));

		setContentView(page);
	}

	@Override
	protected void onResume() {
		super.onResume();
		updatePermBox();
		refresh();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		exec.shutdown();
	}

	@Override
	public void onBackPressed() {
		if (!sel.isEmpty()) {
			sel.clear();
			adapter.notifyDataSetChanged();
			rebuildBar();
			return;
		}
		File p = cwd.getParentFile();
		if (cwd.equals(startDir) || cwd.equals(root) || p == null) {
			finish();
		} else {
			go(p);
		}
	}

	// ---------------------------------------------------------------- permission

	private boolean hasAccess() {
		if (Build.VERSION.SDK_INT >= 30) {
			return Environment.isExternalStorageManager();
		}
		return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
	}

	private void askAccess() {
		if (Build.VERSION.SDK_INT >= 30) {
			try {
				startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
						Uri.parse("package:" + getPackageName())));
			} catch (Exception e) {
				startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
			}
		} else {
			requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
					Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		updatePermBox();
		refresh();
	}

	private void updatePermBox() {
		permBox.setVisibility(hasAccess() ? View.GONE : View.VISIBLE);
	}

	// ---------------------------------------------------------------- listing

	private void refresh() {
		items.clear();
		File[] f = cwd.listFiles();
		listFailed = f == null;
		if (f != null) {
			for (File x : f) {
				if (showHidden || !x.getName().startsWith(".")) {
					items.add(x);
				}
			}
		}
		Collections.sort(items, comparator());
		sel.retainAll(items);
		adapter.notifyDataSetChanged();
		updateStatus();
		rebuildBar();
	}

	private Comparator<File> comparator() {
		return (a, b) -> {
			if (a.isDirectory() != b.isDirectory()) {
				return a.isDirectory() ? -1 : 1;
			}
			if (sortMode == 1) {
				int c = Long.compare(b.length(), a.length());
				if (c != 0) {
					return c;
				}
			} else if (sortMode == 2) {
				int c = Long.compare(b.lastModified(), a.lastModified());
				if (c != 0) {
					return c;
				}
			}
			return a.getName().compareToIgnoreCase(b.getName());
		};
	}

	private void updateStatus() {
		String p = cwd.getAbsolutePath();
		String s;
		boolean restricted = p.contains("/Android/data") || p.contains("/Android/obb");
		if (restricted && items.isEmpty()) {
			s = "Android blocks this folder: file managers cannot open other apps' Android/data or Android/obb.";
		} else if (listFailed) {
			s = "Cannot read this folder.";
		} else {
			s = items.size() + " items";
			long free = cwd.getUsableSpace();
			if (free > 0) {
				s += "   •   free " + FileOps.size(free);
			}
		}
		status.setText(s);
		if (clip.isEmpty()) {
			pasteBtn.setVisibility(View.GONE);
		} else {
			pasteBtn.setText("Paste " + clip.size() + (clipCut ? " (move)" : " (copy)") + " here");
			pasteBtn.setVisibility(View.VISIBLE);
		}
	}

	private void go(File dir) {
		cwd = dir;
		sel.clear();
		refresh();
		list.setSelection(0);
	}

	private void goUp() {
		File p = cwd.getParentFile();
		if (p == null || cwd.equals(root)) {
			Util.toast(this, "This is the top of storage.");
			return;
		}
		go(p);
	}

	// ---------------------------------------------------------------- top bar

	private void rebuildBar() {
		barHolder.removeAllViews();
		if (sel.isEmpty()) {
			barHolder.addView(button("⬆ Up", v -> goUp()));
			pathView = text(cwd.getAbsolutePath(), 13, 0xFFCFC6E8);
			pathView.setSingleLine(true);
			pathView.setEllipsize(TextUtils.TruncateAt.START);
			LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, WRAP, 1f);
			pl.leftMargin = dp(6);
			pl.rightMargin = dp(6);
			barHolder.addView(pathView, pl);
			barHolder.addView(button("+ Folder", v -> newFolderDialog()));
			barHolder.addView(button("⬇ Link", v -> downloadDialog()));
			barHolder.addView(button("⋮", v -> showMenu()));
		} else {
			barHolder.addView(button("✕", v -> {
				sel.clear();
				adapter.notifyDataSetChanged();
				rebuildBar();
			}));
			TextView n = text(sel.size() + " selected", 14, Color.WHITE);
			LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(0, WRAP, 1f);
			nl.leftMargin = dp(6);
			barHolder.addView(n, nl);
			final List<File> chosen = new ArrayList<>(sel);
			barHolder.addView(button("Copy", v -> setClip(chosen, false)));
			barHolder.addView(button("Cut", v -> setClip(chosen, true)));
			barHolder.addView(button("Delete", v -> confirmDelete(chosen)));
			if (chosen.size() == 1) {
				barHolder.addView(button("Rename", v -> renameDialog(chosen.get(0))));
			}
			boolean allMods = true;
			for (File f : chosen) {
				if (f.isDirectory() || !FileOps.isModJar(f.getName())) {
					allMods = false;
					break;
				}
			}
			if (allMods) {
				barHolder.addView(button("On/Off", v -> toggleMods(chosen)));
			}
			barHolder.addView(button("All", v -> selectAll()));
		}
	}

	private void showMenu() {
		final String[] labels = {
				"Sort by: " + SORT_NAMES[sortMode] + "  (tap to change)",
				showHidden ? "Hide hidden files" : "Show hidden files",
				"Set this folder as Mods folder",
				"Go to internal storage",
				"Go to Downloads",
				"Go to Mods folder",
				"Select all"
		};
		new AlertDialog.Builder(this).setItems(labels, (d, which) -> {
			switch (which) {
				case 0:
					sortMode = (sortMode + 1) % 3;
					refresh();
					break;
				case 1:
					showHidden = !showHidden;
					refresh();
					break;
				case 2:
					prefs.edit().putString("mods_dir", cwd.getAbsolutePath()).apply();
					Util.toast(this, "Mods folder set to " + cwd.getAbsolutePath());
					break;
				case 3:
					go(root);
					break;
				case 4:
					go(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
					break;
				case 5:
					String m = prefs.getString("mods_dir", null);
					if (m != null && new File(m).isDirectory()) {
						go(new File(m));
					} else {
						Util.toast(this, "No Mods folder set yet.");
					}
					break;
				default:
					selectAll();
					break;
			}
		}).show();
	}

	// ---------------------------------------------------------------- selection and clicks

	private void toggleSelect(File f) {
		if (!sel.remove(f)) {
			sel.add(f);
		}
		adapter.notifyDataSetChanged();
		rebuildBar();
	}

	private void selectAll() {
		sel.clear();
		sel.addAll(items);
		adapter.notifyDataSetChanged();
		rebuildBar();
	}

	private void onRowClick(File f) {
		if (!sel.isEmpty()) {
			toggleSelect(f);
			return;
		}
		if (f.isDirectory()) {
			go(f);
		} else if (FileOps.isWindowsProgram(f.getName())) {
			Util.exeDialog(this, f);
		} else if (FileOps.isModJar(f.getName())) {
			modDialog(f);
		} else {
			Util.open(this, f);
		}
	}

	private void modDialog(final File f) {
		final boolean disabled = FileOps.isDisabledMod(f.getName());
		new AlertDialog.Builder(this)
				.setTitle(f.getName())
				.setItems(new String[]{disabled ? "Enable mod" : "Disable mod", "Delete"}, (d, which) -> {
					List<File> one = new ArrayList<>();
					one.add(f);
					if (which == 0) {
						toggleMods(one);
					} else {
						confirmDelete(one);
					}
				})
				.show();
	}

	// ---------------------------------------------------------------- actions

	private void setClip(List<File> files, boolean cut) {
		clip.clear();
		clip.addAll(files);
		clipCut = cut;
		sel.clear();
		adapter.notifyDataSetChanged();
		updateStatus();
		rebuildBar();
		Util.toast(this, files.size() + (cut ? " item(s) ready to move" : " item(s) copied") + ". Open the target folder and tap Paste.");
	}

	private void paste() {
		final List<File> src = new ArrayList<>(clip);
		final boolean cut = clipCut;
		final File dest = cwd;
		if (cut) {
			clip.clear();
		}
		runWork(cut ? "Moving…" : "Copying…", () -> {
			int ok = 0;
			String firstErr = null;
			for (File f : src) {
				try {
					if (cut) {
						File parent = f.getParentFile();
						if (parent != null && parent.equals(dest)) {
							continue;
						}
						FileOps.move(f, dest);
					} else {
						FileOps.copy(f, dest);
					}
					ok++;
				} catch (Exception e) {
					if (firstErr == null) {
						firstErr = f.getName() + ": " + e.getMessage();
					}
				}
			}
			return firstErr == null ? "Done (" + ok + ")" : "Done " + ok + ", error: " + firstErr;
		});
	}

	private void confirmDelete(final List<File> files) {
		new AlertDialog.Builder(this)
				.setTitle("Delete " + files.size() + " item(s)?")
				.setMessage("This cannot be undone.")
				.setPositiveButton("Delete", (d, w) -> runWork("Deleting…", () -> {
					int bad = 0;
					for (File f : files) {
						if (!FileOps.delete(f)) {
							bad++;
						}
					}
					return bad == 0 ? "Deleted" : bad + " item(s) could not be deleted";
				}))
				.setNegativeButton("Cancel", null)
				.show();
	}

	private void renameDialog(final File f) {
		final EditText et = new EditText(this);
		et.setText(f.getName());
		et.setSelectAllOnFocus(true);
		et.setSingleLine(true);
		new AlertDialog.Builder(this)
				.setTitle("Rename")
				.setView(et)
				.setPositiveButton("OK", (d, w) -> {
					String n = et.getText().toString().trim();
					if (n.isEmpty() || n.contains("/")) {
						Util.toast(this, "Invalid name");
						return;
					}
					File t = new File(f.getParentFile(), n);
					if (t.exists()) {
						Util.toast(this, "That name already exists");
						return;
					}
					if (!f.renameTo(t)) {
						Util.toast(this, "Rename failed");
					}
					sel.clear();
					refresh();
				})
				.setNegativeButton("Cancel", null)
				.show();
	}

	private void newFolderDialog() {
		final EditText et = new EditText(this);
		et.setHint("Folder name");
		et.setSingleLine(true);
		new AlertDialog.Builder(this)
				.setTitle("New folder")
				.setView(et)
				.setPositiveButton("Create", (d, w) -> {
					String n = et.getText().toString().trim();
					if (n.isEmpty() || n.contains("/")) {
						Util.toast(this, "Invalid name");
						return;
					}
					if (!new File(cwd, n).mkdirs()) {
						Util.toast(this, "Could not create the folder");
					}
					refresh();
				})
				.setNegativeButton("Cancel", null)
				.show();
	}

	/** Mods switch: a Fabric/Forge loader ignores a ".jar.disabled" file, so renaming is enough. */
	private void toggleMods(List<File> files) {
		int n = 0;
		for (File f : files) {
			String name = f.getName();
			File target = null;
			if (FileOps.isDisabledMod(name)) {
				target = new File(f.getParentFile(), name.substring(0, name.length() - FileOps.DISABLED_SUFFIX.length()));
			} else if (name.toLowerCase(Locale.ROOT).endsWith(".jar")) {
				target = new File(f.getParentFile(), name + FileOps.DISABLED_SUFFIX);
			}
			if (target != null && !target.exists() && f.renameTo(target)) {
				n++;
			}
		}
		sel.clear();
		refresh();
		Util.toast(this, n + " mod(s) switched");
	}

	private void downloadDialog() {
		final EditText et = new EditText(this);
		et.setHint("https://… (direct link to the file)");
		et.setSingleLine(true);
		et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
		new AlertDialog.Builder(this)
				.setTitle("Download into " + cwd.getName())
				.setView(et)
				.setPositiveButton("Download", (d, w) -> startDownload(et.getText().toString().trim()))
				.setNegativeButton("Cancel", null)
				.show();
	}

	private void startDownload(final String url) {
		if (!url.startsWith("https://")) {
			Util.toast(this, "Only https:// links work.");
			return;
		}
		final File dest = cwd;
		runWork("Connecting…", () -> {
			File out = FileOps.download(url, dest, bytes -> progress("Downloaded " + FileOps.size(bytes)));
			return "Saved " + out.getName() + " (" + FileOps.size(out.length()) + ")";
		});
	}

	// ---------------------------------------------------------------- background work

	private void progress(final String s) {
		runOnUiThread(() -> {
			if (work != null) {
				work.setMessage(s);
			}
		});
	}

	private void runWork(String message, final Job job) {
		work = new AlertDialog.Builder(this).setMessage(message).setCancelable(false).create();
		work.show();
		exec.execute(() -> {
			String res;
			try {
				res = job.run();
			} catch (Exception e) {
				res = "Error: " + e.getMessage();
			}
			final String fin = res;
			runOnUiThread(() -> {
				if (work != null && work.isShowing()) {
					work.dismiss();
				}
				work = null;
				if (isFinishing()) {
					return;
				}
				sel.clear();
				Util.toast(this, fin);
				refresh();
			});
		});
	}

	// ---------------------------------------------------------------- list rows

	private final class ItemAdapter extends BaseAdapter {
		@Override
		public int getCount() {
			return items.size();
		}

		@Override
		public File getItem(int i) {
			return items.get(i);
		}

		@Override
		public long getItemId(int i) {
			return i;
		}

		@Override
		public View getView(int i, View convertView, ViewGroup parent) {
			LinearLayout row;
			if (convertView == null) {
				row = new LinearLayout(FilesActivity.this);
				row.setGravity(Gravity.CENTER_VERTICAL);
				row.setPadding(dp(12), dp(6), dp(12), dp(6));

				TextView icon = new TextView(FilesActivity.this);
				icon.setTextSize(24);
				icon.setGravity(Gravity.CENTER);
				icon.setIncludeFontPadding(false);
				row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(40)));

				LinearLayout col = new LinearLayout(FilesActivity.this);
				col.setOrientation(LinearLayout.VERTICAL);
				TextView name = new TextView(FilesActivity.this);
				name.setTextSize(15);
				name.setSingleLine(true);
				name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
				col.addView(name, new LinearLayout.LayoutParams(MATCH, WRAP));
				TextView meta = new TextView(FilesActivity.this);
				meta.setTextSize(11);
				meta.setTextColor(0xFF9E94BD);
				meta.setSingleLine(true);
				col.addView(meta, new LinearLayout.LayoutParams(MATCH, WRAP));
				LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, WRAP, 1f);
				cl.leftMargin = dp(8);
				row.addView(col, cl);
			} else {
				row = (LinearLayout) convertView;
			}

			File f = items.get(i);
			String n = f.getName();
			boolean disabled = FileOps.isDisabledMod(n);
			TextView icon = (TextView) row.getChildAt(0);
			LinearLayout col = (LinearLayout) row.getChildAt(1);
			TextView name = (TextView) col.getChildAt(0);
			TextView meta = (TextView) col.getChildAt(1);

			icon.setText(iconFor(f));
			name.setText(n);
			name.setTextColor(disabled ? 0xFF7D7496 : Color.WHITE);
			String date = DateFormat.format("dd MMM yyyy  HH:mm", f.lastModified()).toString();
			if (f.isDirectory()) {
				meta.setText("Folder   •   " + date);
			} else {
				String extra = disabled ? "   •   disabled mod" : "";
				meta.setText(FileOps.size(f.length()) + "   •   " + date + extra);
			}
			row.setBackground(sel.contains(f) ? new ColorDrawable(0x444A2FA0) : pressBg());
			return row;
		}
	}

	private String iconFor(File f) {
		if (f.isDirectory()) {
			return "📁";
		}
		String n = f.getName();
		if (FileOps.isDisabledMod(n)) {
			return "⏸️";
		}
		if (FileOps.isModJar(n)) {
			return "🧩";
		}
		if (FileOps.isWindowsProgram(n)) {
			return "🖥️";
		}
		String e = FileOps.ext(n);
		if (e.equals("zip") || e.equals("rar") || e.equals("7z") || e.equals("tar") || e.equals("gz")) {
			return "🗜️";
		}
		if (e.equals("png") || e.equals("jpg") || e.equals("jpeg") || e.equals("webp") || e.equals("gif")) {
			return "🖼️";
		}
		return "📄";
	}

	// ---------------------------------------------------------------- view helpers

	private TextView text(String s, float sp, int color) {
		TextView t = new TextView(this);
		t.setText(s);
		t.setTextSize(sp);
		t.setTextColor(color);
		return t;
	}

	private TextView button(String label, View.OnClickListener l) {
		TextView t = text(label, 14, Color.WHITE);
		t.setGravity(Gravity.CENTER);
		t.setPadding(dp(12), dp(10), dp(12), dp(10));
		t.setBackground(pressBg());
		t.setOnClickListener(l);
		return t;
	}

	private Drawable pressBg() {
		StateListDrawable sl = new StateListDrawable();
		GradientDrawable pressed = new GradientDrawable();
		pressed.setColor(0x33FFFFFF);
		pressed.setCornerRadius(dp(6));
		sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
		sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
		return sl;
	}

	private int dp(float v) {
		return Util.dp(this, v);
	}
}
