package dev.lumen.desktop;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * The "mini PC" home screen: landscape desktop with icons, a taskbar (Start, free RAM, battery, clock)
 * and a Start menu listing every installed app. Plain Views, no libraries, nothing animated.
 */
public class DesktopActivity extends Activity {
	private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
	private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
	private static final String P_PINS = "pins";
	private static final String P_MODS = "mods_dir";

	private SharedPreferences prefs;
	private GridLayout grid;
	private TextView clock;
	private TextView ram;
	private TextView battery;
	private final Handler handler = new Handler(Looper.getMainLooper());
	private final Runnable ticker = new Runnable() {
		@Override
		public void run() {
			updateStatus();
			handler.postDelayed(this, 10000);
		}
	};
	private List<AppEntry> apps; // loaded the first time the Start menu opens

	private static final class AppEntry {
		String label;
		String pkg;
		Drawable icon;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		prefs = getSharedPreferences("lumen", MODE_PRIVATE);

		FrameLayout root = new FrameLayout(this);
		GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF2A1450, 0xFF0B0716});
		root.setBackground(bg);

		ImageView mark = new ImageView(this);
		mark.setImageResource(R.drawable.logo);
		mark.setAlpha(0.10f);
		root.addView(mark, new FrameLayout.LayoutParams(dp(220), dp(220), Gravity.CENTER));

		LinearLayout col = new LinearLayout(this);
		col.setOrientation(LinearLayout.VERTICAL);

		ScrollView sv = new ScrollView(this);
		grid = new GridLayout(this);
		int cols = Math.max(3, getResources().getConfiguration().screenWidthDp / 112);
		grid.setColumnCount(cols);
		grid.setPadding(dp(20), dp(20), dp(20), dp(8));
		sv.addView(grid, new FrameLayout.LayoutParams(MATCH, WRAP));
		col.addView(sv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
		col.addView(buildTaskbar(), new LinearLayout.LayoutParams(MATCH, dp(52)));

		root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
		setContentView(root);

		if (!prefs.contains(P_PINS)) {
			autoPin();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		buildGrid();
		handler.post(ticker);
	}

	@Override
	protected void onPause() {
		super.onPause();
		handler.removeCallbacks(ticker);
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		if (hasFocus) {
			getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
					| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
					| View.SYSTEM_UI_FLAG_FULLSCREEN
					| View.SYSTEM_UI_FLAG_LAYOUT_STABLE
					| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
					| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
		}
	}

	@Override
	public void onBackPressed() {
		// This is the home screen: Back does nothing, like a desktop.
	}

	// ---------------------------------------------------------------- desktop icons

	private void buildGrid() {
		grid.removeAllViews();
		addCell(makeCell(null, "📁", "Files", v -> openFiles(null), null));
		addCell(makeCell(null, "🧩", "Mods", v -> openMods(), null));
		addCell(makeCell(null, "⬇️", "Downloads", v -> openFiles(Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()), null));
		addCell(makeCell(null, "▦", "All apps", v -> showStart(), null));

		PackageManager pm = getPackageManager();
		List<String> pins = getPins();
		boolean changed = false;
		for (String pkg : new ArrayList<>(pins)) {
			final Intent launch = pm.getLaunchIntentForPackage(pkg);
			if (launch == null) {
				pins.remove(pkg);
				changed = true;
				continue;
			}
			try {
				ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
				final String p = pkg;
				addCell(makeCell(ai.loadIcon(pm), null, String.valueOf(ai.loadLabel(pm)),
						v -> startApp(launch), v -> {
							confirmUnpin(p);
							return true;
						}));
			} catch (PackageManager.NameNotFoundException e) {
				pins.remove(pkg);
				changed = true;
			}
		}
		if (changed) {
			savePins(pins);
		}
	}

	private void addCell(View v) {
		GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
		lp.width = dp(104);
		lp.height = dp(104);
		lp.setMargins(dp(4), dp(4), dp(4), dp(4));
		grid.addView(v, lp);
	}

	private View makeCell(Drawable icon, String emoji, String label, View.OnClickListener click,
						  View.OnLongClickListener longClick) {
		LinearLayout c = new LinearLayout(this);
		c.setOrientation(LinearLayout.VERTICAL);
		c.setGravity(Gravity.CENTER_HORIZONTAL);
		c.setPadding(dp(6), dp(8), dp(6), dp(6));
		c.setBackground(pressBg());
		if (icon != null) {
			ImageView iv = new ImageView(this);
			iv.setImageDrawable(icon);
			c.addView(iv, new LinearLayout.LayoutParams(dp(48), dp(48)));
		} else {
			TextView e = new TextView(this);
			e.setText(emoji);
			e.setTextSize(32);
			e.setGravity(Gravity.CENTER);
			e.setTextColor(Color.WHITE);
			e.setIncludeFontPadding(false);
			c.addView(e, new LinearLayout.LayoutParams(dp(48), dp(48)));
		}
		TextView t = new TextView(this);
		t.setText(label);
		t.setTextColor(Color.WHITE);
		t.setTextSize(12);
		t.setGravity(Gravity.CENTER);
		t.setMaxLines(2);
		t.setEllipsize(TextUtils.TruncateAt.END);
		t.setShadowLayer(3, 0, 1, 0xFF000000);
		LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(MATCH, WRAP);
		tl.topMargin = dp(4);
		c.addView(t, tl);
		c.setOnClickListener(click);
		if (longClick != null) {
			c.setOnLongClickListener(longClick);
		}
		return c;
	}

	private void openFiles(String path) {
		Intent i = new Intent(this, FilesActivity.class);
		if (path != null) {
			i.putExtra(FilesActivity.EXTRA_PATH, path);
		}
		startActivity(i);
	}

	private void openMods() {
		String p = prefs.getString(P_MODS, null);
		if (p == null) {
			Util.toast(this, "Open the folder where your mods are, then menu → Set this folder as Mods folder.");
		}
		openFiles(p);
	}

	private void startApp(Intent launch) {
		if (launch == null) {
			Util.toast(this, "App not found");
			return;
		}
		try {
			startActivity(launch);
		} catch (Exception e) {
			Util.toast(this, "Could not open the app");
		}
	}

	// ---------------------------------------------------------------- pinned apps

	private List<String> getPins() {
		List<String> out = new ArrayList<>();
		for (String p : prefs.getString(P_PINS, "").split("\\|")) {
			if (!p.isEmpty()) {
				out.add(p);
			}
		}
		return out;
	}

	private void savePins(List<String> l) {
		prefs.edit().putString(P_PINS, TextUtils.join("|", l)).apply();
	}

	/** First run: pin any installed app with "lumen" in its name (e.g. Lumen Launcher). */
	private void autoPin() {
		List<String> pins = new ArrayList<>();
		PackageManager pm = getPackageManager();
		Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
		for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
			String pkg = r.activityInfo.packageName;
			if (pkg.equals(getPackageName())) {
				continue;
			}
			String label = String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT);
			if (label.contains("lumen") && !pins.contains(pkg)) {
				pins.add(pkg);
			}
		}
		savePins(pins);
	}

	private void confirmUnpin(final String pkg) {
		new AlertDialog.Builder(this)
				.setTitle("Remove from desktop?")
				.setPositiveButton("Remove", (d, w) -> {
					List<String> pins = getPins();
					pins.remove(pkg);
					savePins(pins);
					buildGrid();
				})
				.setNegativeButton("Cancel", null)
				.show();
	}

	private void pinDialog(final AppEntry e) {
		new AlertDialog.Builder(this)
				.setTitle(e.label)
				.setItems(new String[]{"Pin to desktop"}, (d, which) -> {
					List<String> pins = getPins();
					if (!pins.contains(e.pkg)) {
						pins.add(e.pkg);
						savePins(pins);
						buildGrid();
					}
					Util.toast(this, "Pinned");
				})
				.show();
	}

	// ---------------------------------------------------------------- taskbar

	private View buildTaskbar() {
		LinearLayout bar = new LinearLayout(this);
		bar.setOrientation(LinearLayout.HORIZONTAL);
		bar.setGravity(Gravity.CENTER_VERTICAL);
		bar.setBackgroundColor(0xF00E0A1A);
		bar.setPadding(dp(8), 0, dp(14), 0);

		TextView start = barText("⊞  Start", 15);
		start.setBackground(pressBg());
		start.setPadding(dp(14), dp(8), dp(14), dp(8));
		start.setOnClickListener(v -> showStart());
		bar.addView(start, new LinearLayout.LayoutParams(WRAP, WRAP));

		bar.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));

		ram = barText("", 12);
		battery = barText("", 12);
		clock = barText("", 13);
		bar.addView(ram, new LinearLayout.LayoutParams(WRAP, WRAP));
		LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(WRAP, WRAP);
		bl.leftMargin = dp(16);
		bar.addView(battery, bl);
		LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
		cl.leftMargin = dp(16);
		bar.addView(clock, cl);
		return bar;
	}

	private TextView barText(String s, float sp) {
		TextView t = new TextView(this);
		t.setText(s);
		t.setTextColor(Color.WHITE);
		t.setTextSize(sp);
		return t;
	}

	private void updateStatus() {
		clock.setText(DateFormat.getTimeFormat(this).format(new Date()));

		ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
		if (am != null) {
			ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
			am.getMemoryInfo(mi);
			ram.setText("RAM " + (mi.availMem >> 20) + " MB free");
		}

		Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		if (b != null) {
			int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
			int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
			if (level >= 0 && scale > 0) {
				battery.setText("🔋 " + (level * 100 / scale) + "%");
			}
		}
	}

	// ---------------------------------------------------------------- start menu

	private void showStart() {
		if (apps != null) {
			showStartNow();
			return;
		}
		Util.toast(this, "Loading apps…");
		new Thread(() -> {
			final List<AppEntry> l = loadApps();
			runOnUiThread(() -> {
				apps = l;
				if (!isFinishing()) {
					showStartNow();
				}
			});
		}).start();
	}

	private List<AppEntry> loadApps() {
		PackageManager pm = getPackageManager();
		Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
		List<AppEntry> out = new ArrayList<>();
		for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
			if (r.activityInfo.packageName.equals(getPackageName())) {
				continue;
			}
			AppEntry e = new AppEntry();
			e.pkg = r.activityInfo.packageName;
			e.label = String.valueOf(r.loadLabel(pm));
			e.icon = r.loadIcon(pm);
			out.add(e);
		}
		Collections.sort(out, (a, b) -> a.label.compareToIgnoreCase(b.label));
		return out;
	}

	private void showStartNow() {
		final Dialog dlg = new Dialog(this);
		dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

		LinearLayout box = new LinearLayout(this);
		box.setOrientation(LinearLayout.VERTICAL);
		box.setPadding(dp(10), dp(10), dp(10), dp(10));

		EditText search = new EditText(this);
		search.setHint("Search apps");
		search.setSingleLine(true);
		search.setTextColor(Color.WHITE);
		search.setHintTextColor(0x99FFFFFF);
		box.addView(search, new LinearLayout.LayoutParams(MATCH, WRAP));

		ListView lv = new ListView(this);
		final AppAdapter ad = new AppAdapter(apps);
		lv.setAdapter(ad);
		lv.setOnItemClickListener((parent, view, pos, id) -> {
			startApp(getPackageManager().getLaunchIntentForPackage(ad.getItem(pos).pkg));
			dlg.dismiss();
		});
		lv.setOnItemLongClickListener((parent, view, pos, id) -> {
			pinDialog(ad.getItem(pos));
			return true;
		});
		box.addView(lv, new LinearLayout.LayoutParams(MATCH, 0, 1f));

		search.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int a, int b, int c) {
			}

			@Override
			public void onTextChanged(CharSequence s, int a, int b, int c) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				ad.filter(s.toString());
			}
		});

		dlg.setContentView(box);
		Window w = dlg.getWindow();
		if (w != null) {
			w.setBackgroundDrawable(roundBg(0xF2160F26, 14));
			w.setLayout(dp(380), dp(340));
			w.setGravity(Gravity.BOTTOM | Gravity.START);
			WindowManager.LayoutParams lp = w.getAttributes();
			lp.x = dp(8);
			lp.y = dp(58);
			w.setAttributes(lp);
		}
		dlg.show();
	}

	private final class AppAdapter extends BaseAdapter {
		private final List<AppEntry> all;
		private List<AppEntry> shown;

		AppAdapter(List<AppEntry> a) {
			all = a;
			shown = new ArrayList<>(a);
		}

		void filter(String query) {
			String q = query.trim().toLowerCase(Locale.ROOT);
			List<AppEntry> n = new ArrayList<>();
			for (AppEntry e : all) {
				if (q.isEmpty() || e.label.toLowerCase(Locale.ROOT).contains(q)) {
					n.add(e);
				}
			}
			shown = n;
			notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			return shown.size();
		}

		@Override
		public AppEntry getItem(int i) {
			return shown.get(i);
		}

		@Override
		public long getItemId(int i) {
			return i;
		}

		@Override
		public View getView(int i, View convertView, ViewGroup parent) {
			LinearLayout row;
			if (convertView == null) {
				row = new LinearLayout(DesktopActivity.this);
				row.setGravity(Gravity.CENTER_VERTICAL);
				row.setPadding(dp(8), dp(6), dp(8), dp(6));
				row.addView(new ImageView(DesktopActivity.this), new LinearLayout.LayoutParams(dp(36), dp(36)));
				TextView tv = new TextView(DesktopActivity.this);
				tv.setTextColor(Color.WHITE);
				tv.setTextSize(15);
				tv.setSingleLine(true);
				LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
				lp.leftMargin = dp(12);
				row.addView(tv, lp);
			} else {
				row = (LinearLayout) convertView;
			}
			AppEntry e = shown.get(i);
			((ImageView) row.getChildAt(0)).setImageDrawable(e.icon);
			((TextView) row.getChildAt(1)).setText(e.label);
			return row;
		}
	}

	// ---------------------------------------------------------------- drawing helpers

	private Drawable pressBg() {
		StateListDrawable sl = new StateListDrawable();
		GradientDrawable pressed = new GradientDrawable();
		pressed.setColor(0x33FFFFFF);
		pressed.setCornerRadius(dp(8));
		sl.addState(new int[]{android.R.attr.state_pressed}, pressed);
		sl.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
		return sl;
	}

	private Drawable roundBg(int color, int radiusDp) {
		GradientDrawable g = new GradientDrawable();
		g.setColor(color);
		g.setCornerRadius(dp(radiusDp));
		return g;
	}

	private int dp(float v) {
		return Util.dp(this, v);
	}
}
