package dev.lumen.desktop;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Locale;
import java.util.function.LongConsumer;

/**
 * File helpers with no Android imports, so they can be compiled and tested on a plain JDK.
 */
final class FileOps {
	static final String DISABLED_SUFFIX = ".disabled";

	private FileOps() {
	}

	static String size(long b) {
		if (b < 1024) {
			return b + " B";
		}
		double k = b / 1024.0;
		if (k < 1024) {
			return String.format(Locale.US, "%.0f KB", k);
		}
		double m = k / 1024.0;
		if (m < 1024) {
			return String.format(Locale.US, "%.1f MB", m);
		}
		return String.format(Locale.US, "%.2f GB", m / 1024.0);
	}

	static String ext(String name) {
		int i = name.lastIndexOf('.');
		return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
	}

	/** True for a mod jar, enabled or disabled. */
	static boolean isModJar(String name) {
		String n = name.toLowerCase(Locale.ROOT);
		return n.endsWith(".jar") || n.endsWith(".jar" + DISABLED_SUFFIX);
	}

	static boolean isDisabledMod(String name) {
		return name.toLowerCase(Locale.ROOT).endsWith(".jar" + DISABLED_SUFFIX);
	}

	static boolean isWindowsProgram(String name) {
		String e = ext(name);
		return e.equals("exe") || e.equals("msi") || e.equals("bat");
	}

	/** name -> name (1) -> name (2) ... so nothing is ever overwritten. */
	static File uniqueTarget(File dir, String name) {
		File f = new File(dir, name);
		if (!f.exists()) {
			return f;
		}
		String base = name;
		String ext = "";
		int dot = name.lastIndexOf('.');
		if (dot > 0) {
			base = name.substring(0, dot);
			ext = name.substring(dot);
		}
		for (int i = 1; i < 1000; i++) {
			f = new File(dir, base + " (" + i + ")" + ext);
			if (!f.exists()) {
				return f;
			}
		}
		return new File(dir, base + "_" + System.currentTimeMillis() + ext);
	}

	static void copy(File src, File dir) throws IOException {
		File dst = uniqueTarget(dir, src.getName());
		if (src.isDirectory()) {
			String s = src.getCanonicalPath() + File.separator;
			if ((dir.getCanonicalPath() + File.separator).startsWith(s)) {
				throw new IOException("Cannot copy a folder into itself");
			}
			if (!dst.mkdirs()) {
				throw new IOException("Cannot create " + dst.getName());
			}
			File[] kids = src.listFiles();
			if (kids != null) {
				for (File k : kids) {
					copy(k, dst);
				}
			}
		} else {
			try (InputStream in = new java.io.FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
				byte[] buf = new byte[64 * 1024];
				int n;
				while ((n = in.read(buf)) != -1) {
					out.write(buf, 0, n);
				}
			}
		}
	}

	static void move(File src, File dir) throws IOException {
		File dst = uniqueTarget(dir, src.getName());
		if (src.renameTo(dst)) {
			return;
		}
		copy(src, dir);
		if (!delete(src)) {
			throw new IOException("Copied, but could not remove the original " + src.getName());
		}
	}

	static boolean delete(File f) {
		if (f.isDirectory()) {
			File[] kids = f.listFiles();
			if (kids != null) {
				for (File k : kids) {
					delete(k);
				}
			}
		}
		return f.delete();
	}

	/** Reduce a URL path or header value to a safe file name. */
	static String safeName(String raw) {
		if (raw == null) {
			return "download";
		}
		String n = raw;
		int q = n.indexOf('?');
		if (q >= 0) {
			n = n.substring(0, q);
		}
		int s = Math.max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
		if (s >= 0) {
			n = n.substring(s + 1);
		}
		try {
			n = URLDecoder.decode(n, "UTF-8");
		} catch (Exception ignore) {
			// keep the undecoded name
		}
		n = n.replaceAll("[^A-Za-z0-9._ +()\\-]", "_").trim();
		while (n.startsWith(".")) {
			n = n.substring(1);
		}
		if (n.isEmpty()) {
			n = "download";
		}
		if (n.length() > 120) {
			n = n.substring(n.length() - 120);
		}
		return n;
	}

	static String dispositionName(String header) {
		if (header == null) {
			return null;
		}
		int i = header.toLowerCase(Locale.ROOT).indexOf("filename=");
		if (i < 0) {
			return null;
		}
		String v = header.substring(i + 9).trim();
		int semi = v.indexOf(';');
		if (semi >= 0) {
			v = v.substring(0, semi).trim();
		}
		if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) {
			v = v.substring(1, v.length() - 1);
		}
		return v.isEmpty() ? null : v;
	}

	/** Downloads to dir, following up to 5 redirects. Never overwrites; returns the saved file. */
	static File download(String urlStr, File dir, LongConsumer progress) throws IOException {
		URL u = new URL(urlStr);
		boolean startedHttps = u.getProtocol().equals("https");
		HttpURLConnection c = null;
		for (int hop = 0;; hop++) {
			if (hop > 5) {
				throw new IOException("Too many redirects");
			}
			c = (HttpURLConnection) u.openConnection();
			c.setInstanceFollowRedirects(false);
			c.setConnectTimeout(15000);
			c.setReadTimeout(30000);
			c.setRequestProperty("User-Agent", "LumenDesktop/0.1");
			int code = c.getResponseCode();
			if (code >= 300 && code < 400) {
				String loc = c.getHeaderField("Location");
				c.disconnect();
				if (loc == null) {
					throw new IOException("Redirect without a location");
				}
				u = new URL(u, loc);
				String proto = u.getProtocol();
				if (!proto.equals("https") && !proto.equals("http")) {
					throw new IOException("Unsupported redirect");
				}
				if (startedHttps && proto.equals("http")) {
					throw new IOException("Refused an https to http downgrade");
				}
				continue;
			}
			if (code != 200) {
				c.disconnect();
				throw new IOException("HTTP " + code);
			}
			break;
		}

		String name = dispositionName(c.getHeaderField("Content-Disposition"));
		if (name == null) {
			name = u.getPath();
		}
		String safe = safeName(name);
		File tmp = new File(dir, safe + ".part");
		long total = 0;
		long lastReport = 0;
		try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
			byte[] buf = new byte[64 * 1024];
			int n;
			while ((n = in.read(buf)) != -1) {
				out.write(buf, 0, n);
				total += n;
				long now = System.currentTimeMillis();
				if (progress != null && now - lastReport > 400) {
					progress.accept(total);
					lastReport = now;
				}
			}
		} catch (IOException e) {
			tmp.delete();
			throw e;
		} finally {
			c.disconnect();
		}
		File dst = uniqueTarget(dir, safe);
		if (!tmp.renameTo(dst)) {
			tmp.delete();
			throw new IOException("Cannot save the file here");
		}
		return dst;
	}
}
