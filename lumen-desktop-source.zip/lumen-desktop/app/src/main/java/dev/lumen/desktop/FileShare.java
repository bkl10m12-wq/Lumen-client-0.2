package dev.lumen.desktop;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Tiny read-only provider so "open with" can hand a file to another app.
 * Not exported: only an app that was explicitly granted the exact Uri can read it.
 */
public class FileShare extends ContentProvider {
	static final String AUTH = "dev.lumen.desktop.files";

	static Uri uriFor(File f) {
		return new Uri.Builder()
				.scheme("content")
				.authority(AUTH)
				.path("/f")
				.appendQueryParameter("p", f.getAbsolutePath())
				.build();
	}

	private static File fileOf(Uri u) {
		String p = u.getQueryParameter("p");
		return p == null ? null : new File(p);
	}

	@Override
	public boolean onCreate() {
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
		File f = fileOf(uri);
		if (f == null) {
			return null;
		}
		MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
		c.addRow(new Object[]{f.getName(), f.length()});
		return c;
	}

	@Override
	public String getType(Uri uri) {
		File f = fileOf(uri);
		return f == null ? null : Util.mime(f.getName());
	}

	@Override
	public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
		File f = fileOf(uri);
		if (f == null || !f.isFile()) {
			throw new FileNotFoundException();
		}
		return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		return null;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		return 0;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
		return 0;
	}
}
