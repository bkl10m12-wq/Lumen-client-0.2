package dev.lumen.desktop;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

import java.io.File;

/** Small Android helpers shared by both screens. */
final class Util {
	private Util() {
	}

	static int dp(Context c, float v) {
		return Math.round(v * c.getResources().getDisplayMetrics().density);
	}

	static void toast(Context c, String s) {
		Toast.makeText(c, s, Toast.LENGTH_LONG).show();
	}

	static String mime(String name) {
		if (FileOps.isWindowsProgram(name)) {
			return "application/x-msdownload";
		}
		String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(FileOps.ext(name));
		return m == null ? "*/*" : m;
	}

	/** Hand a file to whatever installed app can open it. */
	static void open(Activity a, File f) {
		Intent i = new Intent(Intent.ACTION_VIEW);
		i.setDataAndType(FileShare.uriFor(f), mime(f.getName()));
		i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		try {
			a.startActivity(i);
		} catch (Exception e) {
			toast(a, "No installed app can open this file.");
		}
	}

	static void copyText(Context c, String label, String text) {
		ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
		if (cm != null) {
			cm.setPrimaryClip(ClipData.newPlainText(label, text));
			toast(c, "Copied");
		}
	}

	/** Windows programs: Lumen Desktop cannot run them itself, so be upfront about it. */
	static void exeDialog(final Activity a, final File f) {
		new AlertDialog.Builder(a)
				.setTitle(f.getName())
				.setMessage("Android cannot run Windows programs by itself. Another app that provides a Windows "
						+ "compatibility layer (for example Winlator) must be installed.\n\n"
						+ "Lumen Desktop can hand this file over or copy its path so you can pick it inside that app. "
						+ "Whether it runs on this phone has not been verified yet.")
				.setPositiveButton("Try to open", (d, w) -> open(a, f))
				.setNeutralButton("Copy path", (d, w) -> copyText(a, "path", f.getAbsolutePath()))
				.setNegativeButton("Close", null)
				.show();
	}
}
