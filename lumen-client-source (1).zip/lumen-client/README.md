<p align="center"><img src="logo.png" width="160" alt="Lumen Client"></p>

# Lumen Client 0.1.0

A very small Fabric mod (client side only) for **Minecraft 1.21.4**, made for Lumen Launcher on low-end phones.
The source is a handful of small Java files, and the finished jar should be well under 100 KB (not measured yet, because it has not been built).

## What it does

1. **One-time settings preset.** On the first launch, at the title screen, it sets a low-end (or balanced) set of options: render distance, simulation distance, entity distance, biome blend, fast graphics, minimal particles, no clouds, no entity shadows, vsync off, uncapped fps, no view bobbing / FOV effects.
   It **never changes resolution or GUI scale.** After that one time you can change any setting yourself and it will not touch it again.
2. **Overlay** in the top-left corner: `FPS | tick avg/max ms | heap % | GC %`.
   - `tick` is the time the integrated (single-player) server needs per tick. Vanilla budget is 50 ms. Over 50 ms = world simulation is the problem, not rendering.
   - `heap %` close to 100 together with a high `GC %` means the JVM is spending its time cleaning memory.
3. **Diagnostic log** `logs/lumen-diag.csv` (one line every 5 s in a world) and `logs/lumen-device.txt` (CPU, cores, RAM, Java, heap size).
   Send these two files after a lag session and the cause can be read from the numbers.

## What it does NOT do

- It does **not** contain a renderer or any optimisation of its own. It cannot raise fps by itself beyond what the preset settings give.
- It does **not** promise 250 or 300 fps. No fps number is guaranteed on any phone.
- It does not include or copy any other client or mod.

## Install

1. Fabric Loader for Minecraft 1.21.4 plus Fabric API 0.119.4+1.21.4 (or a compatible Fabric API build).
2. Put `lumen-client-0.1.0.jar` into the instance `mods` folder.

## Build (needs Java 21)

**GitHub Actions (no setup on your side):** create a repo, upload these files, open the *Actions* tab, run `build`, download `lumen-client-jar`.

**Locally:** `gradle build` (Gradle 8.12). The jar appears in `build/libs/`.

## Config

`config/lumen-client.properties`

| key | meaning |
|---|---|
| `hud` | show the overlay |
| `csv` / `csvIntervalSec` | write the CSV log, and how often |
| `preset` | `auto`, `lowend`, `balanced`, `off` (`auto` = lowend below 10 GB RAM) |
| `forcePresetEveryLaunch` | re-apply the preset on every start |

## Status

The pure-Java parts (config, device info, sampler, CSV) were compiled and tested.
The parts that touch Minecraft (`Preset`, `Hud`, `LumenClient`) were written against the 1.21.4 Yarn docs but **have not been compiled or run yet**, because the Fabric/Mojang servers were not reachable where this was written. If the first build reports a missing method name, that is the place to look.
