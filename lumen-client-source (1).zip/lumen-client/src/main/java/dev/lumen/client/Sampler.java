package dev.lumen.client;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.Collections;
import java.util.List;

/**
 * Collects the numbers that explain WHY a world lags: tick time of the integrated server,
 * heap usage and the share of wall-clock time spent in garbage collection.
 * No Minecraft classes here.
 */
public final class Sampler {
	private final long[] ring = new long[100]; // last 100 server ticks, in nanoseconds
	private int idx;
	private int count;
	private long startNs;

	private final List<GarbageCollectorMXBean> gcBeans;
	private long lastGcMs = -1;
	private long lastWallMs = -1;
	private volatile double gcPercent = 0;

	public Sampler() {
		List<GarbageCollectorMXBean> beans;
		try {
			beans = ManagementFactory.getGarbageCollectorMXBeans();
		} catch (Throwable t) {
			// some mobile JREs ship without java.management; then GC% simply stays 0
			beans = Collections.emptyList();
		}
		this.gcBeans = beans;
	}

	public synchronized void tickStart() {
		startNs = System.nanoTime();
	}

	public synchronized void tickEnd() {
		if (startNs == 0) {
			return;
		}
		ring[idx] = System.nanoTime() - startNs;
		idx = (idx + 1) % ring.length;
		if (count < ring.length) {
			count++;
		}
	}

	public synchronized double avgTickMs() {
		if (count == 0) {
			return -1;
		}
		long sum = 0;
		for (int i = 0; i < count; i++) {
			sum += ring[i];
		}
		return sum / (double) count / 1_000_000.0;
	}

	public synchronized double maxTickMs() {
		if (count == 0) {
			return -1;
		}
		long max = 0;
		for (int i = 0; i < count; i++) {
			max = Math.max(max, ring[i]);
		}
		return max / 1_000_000.0;
	}

	public synchronized void resetTicks() {
		count = 0;
		idx = 0;
		startNs = 0;
	}

	/** Call about once per second. Updates the GC share of the last interval. */
	public void sampleGc() {
		long gcMs = 0;
		for (GarbageCollectorMXBean b : gcBeans) {
			long t = b.getCollectionTime();
			if (t > 0) {
				gcMs += t;
			}
		}
		long wallMs = System.currentTimeMillis();
		if (lastWallMs > 0 && wallMs > lastWallMs) {
			double pct = 100.0 * (gcMs - lastGcMs) / (double) (wallMs - lastWallMs);
			gcPercent = Math.max(0, Math.min(100, pct));
		}
		lastGcMs = gcMs;
		lastWallMs = wallMs;
	}

	public double gcPercent() {
		return gcPercent;
	}

	public static long heapUsedMb() {
		Runtime rt = Runtime.getRuntime();
		return (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
	}

	public static long heapMaxMb() {
		return Runtime.getRuntime().maxMemory() / (1024 * 1024);
	}

	public static int heapPercent() {
		long max = heapMaxMb();
		return max <= 0 ? 0 : (int) (100 * heapUsedMb() / max);
	}
}
