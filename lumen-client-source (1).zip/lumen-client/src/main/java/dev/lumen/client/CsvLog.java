package dev.lumen.client;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/** Append-only CSV writer. If the file can't be written it silently turns itself off. */
public final class CsvLog implements AutoCloseable {
	private BufferedWriter out;

	public CsvLog(Path file, String header) {
		try {
			if (file.getParent() != null) {
				Files.createDirectories(file.getParent());
			}
			boolean fresh = !Files.exists(file) || Files.size(file) == 0;
			out = Files.newBufferedWriter(file, StandardCharsets.UTF_8,
				StandardOpenOption.CREATE, StandardOpenOption.APPEND);
			if (fresh) {
				out.write(header);
				out.newLine();
				out.flush();
			}
		} catch (IOException e) {
			out = null;
		}
	}

	public void line(String s) {
		if (out == null) {
			return;
		}
		try {
			out.write(s);
			out.newLine();
			out.flush();
		} catch (IOException e) {
			out = null;
		}
	}

	@Override
	public void close() {
		if (out != null) {
			try {
				out.close();
			} catch (IOException ignored) {
				// nothing to do
			}
			out = null;
		}
	}
}
