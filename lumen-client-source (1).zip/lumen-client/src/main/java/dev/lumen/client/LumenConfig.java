package dev.lumen.client;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Plain properties file: config/lumen-client.properties. No Minecraft classes in here. */
public final class LumenConfig {
	/** Show the small overlay (FPS / tick / heap / GC). */
	public boolean hud = true;
	/** Write logs/lumen-diag.csv while playing. */
	public boolean csv = true;
	public int csvIntervalSec = 5;
	/** auto | lowend | balanced | off */
	public String preset = "auto";
	/** Preset is applied once, then you are free to change settings yourself. */
	public boolean presetApplied = false;
	/** Set true to re-apply the preset on every launch. */
	public boolean forcePresetEveryLaunch = false;

	private final Path file;

	private LumenConfig(Path file) {
		this.file = file;
	}

	public static LumenConfig load(Path file) {
		LumenConfig c = new LumenConfig(file);
		if (!Files.isRegularFile(file)) {
			return c;
		}
		Properties p = new Properties();
		try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			p.load(r);
		} catch (IOException | IllegalArgumentException e) {
			return c;
		}
		c.hud = bool(p, "hud", c.hud);
		c.csv = bool(p, "csv", c.csv);
		c.csvIntervalSec = Math.max(1, integer(p, "csvIntervalSec", c.csvIntervalSec));
		String pr = p.getProperty("preset", c.preset).trim().toLowerCase();
		if (pr.equals("auto") || pr.equals("lowend") || pr.equals("balanced") || pr.equals("off")) {
			c.preset = pr;
		}
		c.presetApplied = bool(p, "presetApplied", c.presetApplied);
		c.forcePresetEveryLaunch = bool(p, "forcePresetEveryLaunch", c.forcePresetEveryLaunch);
		return c;
	}

	public void save() {
		Properties p = new Properties();
		p.setProperty("hud", Boolean.toString(hud));
		p.setProperty("csv", Boolean.toString(csv));
		p.setProperty("csvIntervalSec", Integer.toString(csvIntervalSec));
		p.setProperty("preset", preset);
		p.setProperty("presetApplied", Boolean.toString(presetApplied));
		p.setProperty("forcePresetEveryLaunch", Boolean.toString(forcePresetEveryLaunch));
		try {
			if (file.getParent() != null) {
				Files.createDirectories(file.getParent());
			}
			try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
				p.store(w, "Lumen Client config. preset = auto | lowend | balanced | off");
			}
		} catch (IOException ignored) {
			// config is optional; never crash the game over it
		}
	}

	private static boolean bool(Properties p, String key, boolean def) {
		String v = p.getProperty(key);
		return v == null ? def : Boolean.parseBoolean(v.trim());
	}

	private static int integer(Properties p, String key, int def) {
		try {
			return Integer.parseInt(p.getProperty(key, "").trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}
}
