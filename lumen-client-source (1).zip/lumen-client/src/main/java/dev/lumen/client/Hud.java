package dev.lumen.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** One line of text. The string is rebuilt twice a second elsewhere, so drawing costs almost nothing. */
final class Hud {
	static volatile String text = "";

	private Hud() {
	}

	static void render(DrawContext context, RenderTickCounter tickCounter) {
		LumenConfig c = LumenClient.config;
		if (c == null || !c.hud || text.isEmpty()) {
			return;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		context.drawTextWithShadow(mc.textRenderer, text, 4, 4, 0xFFFFFFFF);
	}
}
