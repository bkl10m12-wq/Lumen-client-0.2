package dev.lumen.client;

import java.io.BufferedReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Reads what the phone/JVM reports about itself. Every read is best-effort; unknown = -1 / "unknown". */
public final class DeviceInfo {
	private DeviceInfo() {
	}

	public static long memTotalMb() {
		return meminfoMb("MemTotal");
	}

	public static long memAvailableMb() {
		return meminfoMb("MemAvailable");
	}

	private static long meminfoMb(String key) {
		try (BufferedReader r = Files.newBufferedReader(Path.of("/proc/meminfo"), StandardCharsets.UTF_8)) {
			String line;
			while ((line = r.readLine()) != null) {
				if (line.startsWith(key + ":")) {
					String[] parts = line.trim().split("\\s+");
					return Long.parseLong(parts[1]) / 1024L;
				}
			}
		} catch (Exception ignored) {
			// /proc may be missing or blocked
		}
		return -1;
	}

	public static String cpuName() {
		try (BufferedReader r = Files.newBufferedReader(Path.of("/proc/cpuinfo"), StandardCharsets.UTF_8)) {
			String line;
			while ((line = r.readLine()) != null) {
				if (line.startsWith("Hardware") || line.startsWith("model name")) {
					int i = line.indexOf(':');
					if (i >= 0) {
						return line.substring(i + 1).trim();
					}
				}
			}
		} catch (Exception ignored) {
			// fall through
		}
		return "unknown";
	}

	public static String summary() {
		Runtime rt = Runtime.getRuntime();
		return "cpu=" + cpuName()
			+ " cores=" + rt.availableProcessors()
			+ " arch=" + System.getProperty("os.arch")
			+ " java=" + System.getProperty("java.version")
			+ " ramTotalMb=" + memTotalMb()
			+ " ramAvailableMb=" + memAvailableMb()
			+ " jvmMaxHeapMb=" + (rt.maxMemory() / (1024 * 1024));
	}

	/**
	 * Picks the preset. Heuristic only: phones that report 10 GB+ of RAM get "balanced",
	 * everything else (including "unknown") gets "lowend".
	 */
	public static String resolvePreset(String configured, long memTotalMb) {
		if (configured != null && !configured.equals("auto")) {
			return configured;
		}
		return memTotalMb >= 10_240 ? "balanced" : "lowend";
	}
}
