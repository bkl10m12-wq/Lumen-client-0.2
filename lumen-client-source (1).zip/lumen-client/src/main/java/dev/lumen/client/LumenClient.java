package dev.lumen.client;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class LumenClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("lumen-client");

	static final Sampler SAMPLER = new Sampler();
	static volatile LumenConfig config;

	private CsvLog csv;
	private boolean presetHandled;
	private boolean wasInWorld;
	private long lastSampleMs;
	private long lastHudMs;
	private long lastCsvMs;

	@Override
	public void onInitializeClient() {
		FabricLoader loader = FabricLoader.getInstance();

		LumenConfig cfg = LumenConfig.load(loader.getConfigDir().resolve("lumen-client.properties"));
		cfg.save(); // writes defaults on first run so the file is easy to find and edit
		config = cfg;

		String device = DeviceInfo.summary();
		LOGGER.info("Lumen Client 0.1.0 started. Device: {}", device);

		Path logs = loader.getGameDir().resolve("logs");
		try {
			Files.createDirectories(logs);
			Files.writeString(logs.resolve("lumen-device.txt"), device + System.lineSeparator(),
				StandardCharsets.UTF_8);
		} catch (Exception ignored) {
			// logging is a bonus, never a reason to crash
		}
		if (cfg.csv) {
			csv = new CsvLog(logs.resolve("lumen-diag.csv"),
				"epochSec,fps,tickAvgMs,tickMaxMs,heapUsedMb,heapMaxMb,gcPercent");
		}

		ServerTickEvents.START_SERVER_TICK.register(server -> SAMPLER.tickStart());
		ServerTickEvents.END_SERVER_TICK.register(server -> SAMPLER.tickEnd());
		ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
		HudRenderCallback.EVENT.register(Hud::render);
	}

	private void onClientTick(MinecraftClient client) {
		LumenConfig c = config;
		if (c == null) {
			return;
		}

		// Preset: once, when the title screen is first up (so no world or resource reload is in flight).
		if (!presetHandled && client.currentScreen instanceof TitleScreen) {
			presetHandled = true;
			if (!c.preset.equals("off") && (!c.presetApplied || c.forcePresetEveryLaunch)) {
				String name = DeviceInfo.resolvePreset(c.preset, DeviceInfo.memTotalMb());
				if (!name.equals("off")) {
					Preset.apply(client, name);
					LOGGER.info("Applied '{}' preset", name);
					c.presetApplied = true;
					c.save();
				}
			}
		}

		boolean inWorld = client.world != null;
		if (wasInWorld && !inWorld) {
			SAMPLER.resetTicks();
		}
		wasInWorld = inWorld;

		long now = System.currentTimeMillis();

		if (now - lastSampleMs >= 1000) {
			lastSampleMs = now;
			SAMPLER.sampleGc();
		}

		if (now - lastHudMs >= 500) {
			lastHudMs = now;
			Hud.text = buildText(client);
		}

		if (csv != null && inWorld && now - lastCsvMs >= c.csvIntervalSec * 1000L) {
			lastCsvMs = now;
			csv.line(String.format(Locale.ROOT, "%d,%d,%.2f,%.2f,%d,%d,%.1f",
				now / 1000, client.getCurrentFps(), SAMPLER.avgTickMs(), SAMPLER.maxTickMs(),
				Sampler.heapUsedMb(), Sampler.heapMaxMb(), SAMPLER.gcPercent()));
		}
	}

	private static String buildText(MinecraftClient client) {
		double avg = SAMPLER.avgTickMs();
		double max = SAMPLER.maxTickMs();
		String tick = (client.isIntegratedServerRunning() && avg >= 0)
			? String.format(Locale.ROOT, "%.1f/%.0f ms", avg, max)
			: "-";
		return String.format(Locale.ROOT, "Lumen | FPS %d | tick %s | heap %d%% | GC %.0f%%",
			client.getCurrentFps(), tick, Sampler.heapPercent(), SAMPLER.gcPercent());
	}
}
