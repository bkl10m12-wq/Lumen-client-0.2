package dev.lumen.client;

import java.util.Objects;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.particle.ParticlesMode;

/**
 * One-time settings preset. It never touches resolution / GUI scale (720p stays 720p),
 * and it only writes options whose value actually differs, so nothing reloads needlessly.
 */
final class Preset {
	private Preset() {
	}

	static void apply(MinecraftClient client, String name) {
		GameOptions o = client.options;

		if (name.equals("lowend")) {
			set(o.getViewDistance(), 2);
			set(o.getSimulationDistance(), 5);
			set(o.getEntityDistanceScaling(), 0.5);
			set(o.getBiomeBlendRadius(), 0);
			set(o.getGraphicsMode(), GraphicsMode.FAST);
			set(o.getParticles(), ParticlesMode.MINIMAL);
			set(o.getCloudRenderMode(), CloudRenderMode.OFF);
			set(o.getEntityShadows(), false);
			set(o.getEnableVsync(), false);
			set(o.getMaxFps(), 260); // 260 = "unlimited" in the vanilla slider
			set(o.getBobView(), false);
			set(o.getFovEffectScale(), 0.0);
			set(o.getDistortionEffectScale(), 0.0);
		} else if (name.equals("balanced")) {
			set(o.getViewDistance(), 8);
			set(o.getSimulationDistance(), 6);
			set(o.getEntityDistanceScaling(), 0.75);
			set(o.getBiomeBlendRadius(), 1);
			set(o.getGraphicsMode(), GraphicsMode.FAST);
			set(o.getParticles(), ParticlesMode.DECREASED);
			set(o.getCloudRenderMode(), CloudRenderMode.OFF);
			set(o.getEntityShadows(), false);
			set(o.getEnableVsync(), false);
			set(o.getMaxFps(), 260);
		} else {
			return;
		}

		try {
			o.write();
		} catch (Throwable t) {
			LumenClient.LOGGER.warn("Could not save options.txt: {}", t.toString());
		}
	}

	private static <T> void set(SimpleOption<T> option, T value) {
		try {
			if (!Objects.equals(option.getValue(), value)) {
				option.setValue(value);
			}
		} catch (Throwable t) {
			LumenClient.LOGGER.warn("Preset: skipped one option: {}", t.toString());
		}
	}
}
